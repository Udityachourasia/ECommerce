package com.example.service;

import com.example.model.User;


public interface MailService {

	public void sendEmail(User user);
	
}
